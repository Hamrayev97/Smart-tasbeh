// src/utils/admob.js
// ============================================================
// AdMob Integration for React Native
// Replace IDs with your real AdMob IDs from Google AdMob console
// ============================================================
import { Platform } from 'react-native';

// ⚠️  REPLACE THESE WITH YOUR REAL ADMOB IDs
export const AD_UNIT_IDS = {
  // Banner Ad (Statistics screen)
  banner: Platform.select({
    ios: 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX',
    android: 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX',
    // Test IDs (use during development):
    // ios: 'ca-app-pub-3940256099942544/2934735716',
    // android: 'ca-app-pub-3940256099942544/6300978111',
  }),

  // Interstitial Ad (shown every 20 counts)
  interstitial: Platform.select({
    ios: 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX',
    android: 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX',
    // Test IDs:
    // ios: 'ca-app-pub-3940256099942544/4411468910',
    // android: 'ca-app-pub-3940256099942544/1033173712',
  }),

  // Rewarded Ad (unlock premium features temporarily)
  rewarded: Platform.select({
    ios: 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX',
    android: 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX',
    // Test IDs:
    // ios: 'ca-app-pub-3940256099942544/1712485313',
    // android: 'ca-app-pub-3940256099942544/5224354917',
  }),
};

// ============================================================
// HOW TO USE IN YOUR APP:
//
// 1. Install: npx expo install react-native-google-mobile-ads
//
// 2. Add to app.json plugins section:
//    ["react-native-google-mobile-ads", {
//      "androidAppId": "ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX",
//      "iosAppId": "ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX"
//    }]
//
// 3. Initialize in App.js (already done in App.js below)
//
// 4. BANNER AD usage example:
//    import { BannerAd, BannerAdSize } from 'react-native-google-mobile-ads';
//    <BannerAd unitId={AD_UNIT_IDS.banner} size={BannerAdSize.BANNER} />
//
// 5. INTERSTITIAL AD usage example:
//    import { InterstitialAd, AdEventType } from 'react-native-google-mobile-ads';
//    const interstitial = InterstitialAd.createForAdRequest(AD_UNIT_IDS.interstitial);
//    interstitial.load();
//    // Show when ready:
//    interstitial.addAdEventListener(AdEventType.LOADED, () => interstitial.show());
// ============================================================
