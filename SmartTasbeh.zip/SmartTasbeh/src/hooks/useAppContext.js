// src/hooks/useAppContext.js
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LANGUAGES } from '../data/languages';
import { THEMES, DEFAULT_DHIKRS } from '../data/themes';

const AppContext = createContext(null);

const KEYS = {
  LANG: '@tasbeh_lang',
  DARK: '@tasbeh_dark',
  THEME: '@tasbeh_theme',
  SOUND: '@tasbeh_sound',
  VIBRATION: '@tasbeh_vibration',
  AUTO_RESET: '@tasbeh_auto_reset',
  PREMIUM: '@tasbeh_premium',
  DHIKRS: '@tasbeh_dhikrs',
  ACTIVE_ID: '@tasbeh_active_id',
  STATS: '@tasbeh_stats',
};

export const AppProvider = ({ children }) => {
  const [lang, setLangState] = useState('uz');
  const [darkMode, setDarkModeState] = useState(true);
  const [themeId, setThemeIdState] = useState('emerald');
  const [soundOn, setSoundOnState] = useState(true);
  const [vibrationOn, setVibrationOnState] = useState(true);
  const [autoReset, setAutoResetState] = useState(false);
  const [isPremium, setIsPremiumState] = useState(false);
  const [dhikrs, setDhikrsState] = useState(DEFAULT_DHIKRS);
  const [activeDhikrId, setActiveDhikrIdState] = useState(1);
  const [stats, setStatsState] = useState({});
  const [loaded, setLoaded] = useState(false);

  // Load all settings on mount
  useEffect(() => {
    const load = async () => {
      try {
        const [
          savedLang, savedDark, savedTheme, savedSound,
          savedVibration, savedAutoReset, savedPremium,
          savedDhikrs, savedActiveId, savedStats,
        ] = await Promise.all([
          AsyncStorage.getItem(KEYS.LANG),
          AsyncStorage.getItem(KEYS.DARK),
          AsyncStorage.getItem(KEYS.THEME),
          AsyncStorage.getItem(KEYS.SOUND),
          AsyncStorage.getItem(KEYS.VIBRATION),
          AsyncStorage.getItem(KEYS.AUTO_RESET),
          AsyncStorage.getItem(KEYS.PREMIUM),
          AsyncStorage.getItem(KEYS.DHIKRS),
          AsyncStorage.getItem(KEYS.ACTIVE_ID),
          AsyncStorage.getItem(KEYS.STATS),
        ]);
        if (savedLang) setLangState(savedLang);
        if (savedDark !== null) setDarkModeState(savedDark === 'true');
        if (savedTheme) setThemeIdState(savedTheme);
        if (savedSound !== null) setSoundOnState(savedSound === 'true');
        if (savedVibration !== null) setVibrationOnState(savedVibration === 'true');
        if (savedAutoReset !== null) setAutoResetState(savedAutoReset === 'true');
        if (savedPremium !== null) setIsPremiumState(savedPremium === 'true');
        if (savedDhikrs) setDhikrsState(JSON.parse(savedDhikrs));
        if (savedActiveId) setActiveDhikrIdState(parseInt(savedActiveId));
        if (savedStats) setStatsState(JSON.parse(savedStats));
      } catch (e) {}
      setLoaded(true);
    };
    load();
  }, []);

  // Save helpers
  const setLang = async (v) => { setLangState(v); await AsyncStorage.setItem(KEYS.LANG, v); };
  const setDarkMode = async (v) => { setDarkModeState(v); await AsyncStorage.setItem(KEYS.DARK, String(v)); };
  const setThemeId = async (v) => { setThemeIdState(v); await AsyncStorage.setItem(KEYS.THEME, v); };
  const setSoundOn = async (v) => { setSoundOnState(v); await AsyncStorage.setItem(KEYS.SOUND, String(v)); };
  const setVibrationOn = async (v) => { setVibrationOnState(v); await AsyncStorage.setItem(KEYS.VIBRATION, String(v)); };
  const setAutoReset = async (v) => { setAutoResetState(v); await AsyncStorage.setItem(KEYS.AUTO_RESET, String(v)); };
  const setIsPremium = async (v) => { setIsPremiumState(v); await AsyncStorage.setItem(KEYS.PREMIUM, String(v)); };
  const setActiveDhikrId = async (v) => { setActiveDhikrIdState(v); await AsyncStorage.setItem(KEYS.ACTIVE_ID, String(v)); };

  const saveDhikrs = async (newDhikrs) => {
    setDhikrsState(newDhikrs);
    await AsyncStorage.setItem(KEYS.DHIKRS, JSON.stringify(newDhikrs));
  };

  const saveStats = async (newStats) => {
    setStatsState(newStats);
    await AsyncStorage.setItem(KEYS.STATS, JSON.stringify(newStats));
  };

  // Today's date key
  const todayKey = new Date().toISOString().split('T')[0];

  // Increment count
  const increment = useCallback(async () => {
    const newDhikrs = dhikrs.map(d => {
      if (d.id !== activeDhikrId) return d;
      const newCount = d.currentCount + 1;
      const newTotal = d.totalCount + 1;
      const reached = newCount >= d.target;
      const shouldReset = reached && autoReset;
      return {
        ...d,
        currentCount: shouldReset ? 0 : newCount,
        totalCount: newTotal,
      };
    });
    await saveDhikrs(newDhikrs);

    const newStats = {
      ...stats,
      [todayKey]: {
        ...stats[todayKey],
        [activeDhikrId]: ((stats[todayKey]?.[activeDhikrId]) || 0) + 1,
      },
    };
    await saveStats(newStats);

    const active = dhikrs.find(d => d.id === activeDhikrId);
    if (active && active.currentCount + 1 >= active.target) {
      return true; // goal reached
    }
    return false;
  }, [dhikrs, activeDhikrId, autoReset, stats, todayKey]);

  const resetCurrent = useCallback(async () => {
    const newDhikrs = dhikrs.map(d =>
      d.id === activeDhikrId ? { ...d, currentCount: 0 } : d,
    );
    await saveDhikrs(newDhikrs);
  }, [dhikrs, activeDhikrId]);

  const addDhikr = async (data) => {
    const newDhikr = { id: Date.now(), currentCount: 0, totalCount: 0, ...data };
    await saveDhikrs([...dhikrs, newDhikr]);
  };

  const updateDhikr = async (id, data) => {
    await saveDhikrs(dhikrs.map(d => d.id === id ? { ...d, ...data } : d));
  };

  const deleteDhikr = async (id) => {
    const filtered = dhikrs.filter(d => d.id !== id);
    await saveDhikrs(filtered);
    if (activeDhikrId === id && filtered.length > 0) {
      await setActiveDhikrId(filtered[0].id);
    }
  };

  // Stats helpers
  const getTodayTotal = () =>
    Object.values(stats[todayKey] || {}).reduce((a, b) => a + b, 0);

  const getWeeklyTotal = () => {
    let total = 0;
    for (let i = 0; i < 7; i++) {
      const d = new Date(); d.setDate(d.getDate() - i);
      const key = d.toISOString().split('T')[0];
      total += Object.values(stats[key] || {}).reduce((a, b) => a + b, 0);
    }
    return total;
  };

  const getMonthlyTotal = () => {
    const month = todayKey.slice(0, 7);
    return Object.entries(stats)
      .filter(([k]) => k.startsWith(month))
      .reduce((sum, [, v]) => sum + Object.values(v).reduce((a, b) => a + b, 0), 0);
  };

  const getLifetimeTotal = () => dhikrs.reduce((s, d) => s + d.totalCount, 0);

  const getMostRecited = () => {
    const sorted = [...dhikrs].sort((a, b) => b.totalCount - a.totalCount);
    return sorted[0]?.name || '-';
  };

  const getWeeklyData = () => {
    const dayLabels = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(); d.setDate(d.getDate() - (6 - i));
      const key = d.toISOString().split('T')[0];
      return {
        label: dayLabels[d.getDay()],
        value: Object.values(stats[key] || {}).reduce((a, b) => a + b, 0),
      };
    });
  };

  const activeDhikr = dhikrs.find(d => d.id === activeDhikrId) || dhikrs[0];
  const t = LANGUAGES[lang] || LANGUAGES.en;
  const theme = THEMES[themeId] || THEMES.emerald;

  const colors = darkMode ? {
    bg: '#0A0F0A',
    surface: '#111A11',
    surface2: '#1A2A1A',
    border: '#1E3A1E',
    text: '#F0FDF4',
    textSub: '#6EE7B7',
    textMuted: '#4B7A4B',
  } : {
    bg: '#F0FDF4',
    surface: '#FFFFFF',
    surface2: '#F9FAFB',
    border: '#D1FAE5',
    text: '#064E3B',
    textSub: '#059669',
    textMuted: '#9CA3AF',
  };

  return (
    <AppContext.Provider value={{
      // State
      lang, darkMode, themeId, soundOn, vibrationOn, autoReset, isPremium,
      dhikrs, activeDhikrId, activeDhikr, stats, loaded,
      // Setters
      setLang, setDarkMode, setThemeId, setSoundOn, setVibrationOn,
      setAutoReset, setIsPremium, setActiveDhikrId,
      // Actions
      increment, resetCurrent, addDhikr, updateDhikr, deleteDhikr,
      // Stats
      getTodayTotal, getWeeklyTotal, getMonthlyTotal, getLifetimeTotal,
      getMostRecited, getWeeklyData,
      // Computed
      t, theme, colors,
    }}>
      {loaded ? children : null}
    </AppContext.Provider>
  );
};

export const useApp = () => useContext(AppContext);
