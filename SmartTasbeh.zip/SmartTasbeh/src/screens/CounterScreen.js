// src/screens/CounterScreen.js
import React, { useState, useRef, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView,
  Animated, Modal, TextInput, Vibration, Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { useApp } from '../hooks/useAppContext';

const { width } = Dimensions.get('window');

export default function CounterScreen() {
  const {
    t, theme, colors, darkMode,
    dhikrs, activeDhikr, activeDhikrId, setActiveDhikrId,
    increment, resetCurrent, updateDhikr,
    soundOn, vibrationOn,
    getTodayTotal,
  } = useApp();

  const [showCongrats, setShowCongrats] = useState(false);
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [goalInput, setGoalInput] = useState('');

  // Animations
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const glowAnim = useRef(new Animated.Value(0)).current;
  const congratsAnim = useRef(new Animated.Value(0)).current;

  const animatePress = () => {
    Animated.sequence([
      Animated.parallel([
        Animated.spring(scaleAnim, { toValue: 0.92, useNativeDriver: true, speed: 50 }),
        Animated.timing(glowAnim, { toValue: 1, duration: 100, useNativeDriver: true }),
      ]),
      Animated.parallel([
        Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true, speed: 30 }),
        Animated.timing(glowAnim, { toValue: 0, duration: 300, useNativeDriver: true }),
      ]),
    ]).start();
  };

  const handlePress = useCallback(async () => {
    animatePress();

    if (vibrationOn) {
      try { await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); } catch {}
    }

    const goalReached = await increment();

    if (goalReached) {
      showCongratsAnim();
    }
  }, [increment, vibrationOn]);

  const showCongratsAnim = () => {
    setShowCongrats(true);
    Animated.sequence([
      Animated.spring(congratsAnim, { toValue: 1, useNativeDriver: true }),
      Animated.delay(2500),
      Animated.timing(congratsAnim, { toValue: 0, duration: 300, useNativeDriver: true }),
    ]).start(() => setShowCongrats(false));
  };

  const progressPct = activeDhikr
    ? Math.min(100, (activeDhikr.currentCount / activeDhikr.target) * 100)
    : 0;

  const remaining = activeDhikr
    ? Math.max(0, activeDhikr.target - activeDhikr.currentCount)
    : 0;

  const glowOpacity = glowAnim.interpolate({
    inputRange: [0, 1], outputRange: [0.3, 0.8],
  });

  return (
    <View style={[styles.container, { backgroundColor: colors.bg }]}>
      {/* Dhikr Selector */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.selectorRow}
        contentContainerStyle={styles.selectorContent}
      >
        {dhikrs.map(d => (
          <TouchableOpacity
            key={d.id}
            onPress={() => setActiveDhikrId(d.id)}
            style={[
              styles.selectorChip,
              {
                backgroundColor: d.id === activeDhikrId ? d.color : colors.surface2,
                borderColor: d.id === activeDhikrId ? d.color : colors.border,
                shadowColor: d.id === activeDhikrId ? d.color : 'transparent',
              },
            ]}
          >
            <Text style={[
              styles.selectorText,
              { color: d.id === activeDhikrId ? '#fff' : colors.textSub },
            ]}>
              {d.name}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Arabic Name */}
      {activeDhikr?.arabicName ? (
        <Text style={[styles.arabicText, { color: theme.accent }]}>
          {activeDhikr.arabicName}
        </Text>
      ) : null}
      <Text style={[styles.dhikrLatinName, { color: colors.textMuted }]}>
        {activeDhikr?.name}
      </Text>

      {/* MAIN COUNTER BUTTON */}
      <View style={styles.buttonWrapper}>
        {/* Glow ring */}
        <Animated.View
          style={[
            styles.glowRing,
            { borderColor: theme.primary, opacity: glowOpacity },
          ]}
        />
        <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
          <TouchableOpacity onPress={handlePress} activeOpacity={1}>
            <LinearGradient
              colors={[theme.secondary, theme.primary, theme.dark]}
              start={{ x: 0.2, y: 0.2 }}
              end={{ x: 0.9, y: 0.9 }}
              style={styles.counterBtn}
            >
              <Text style={styles.counterNumber}>
                {activeDhikr?.currentCount ?? 0}
              </Text>
              <Text style={styles.tapLabel}>{t.tapToCount}</Text>
            </LinearGradient>
          </TouchableOpacity>
        </Animated.View>
      </View>

      {/* Progress Bar */}
      <View style={styles.progressSection}>
        <View style={styles.progressLabels}>
          <Text style={[styles.progressLabel, { color: colors.textSub }]}>
            {t.progress}: {Math.round(progressPct)}%
          </Text>
          <Text style={[styles.progressLabel, { color: colors.textMuted }]}>
            {remaining} {t.remaining}
          </Text>
        </View>
        <View style={[styles.progressTrack, { backgroundColor: colors.surface2 }]}>
          <LinearGradient
            colors={[theme.primary, theme.accent]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={[styles.progressFill, { width: `${progressPct}%` }]}
          />
        </View>
      </View>

      {/* Stats Row */}
      <View style={styles.statsRow}>
        {[
          { label: t.today, value: getTodayTotal() },
          { label: t.goal, value: activeDhikr?.target ?? 33 },
          { label: t.totalCount, value: activeDhikr?.totalCount ?? 0 },
        ].map(item => (
          <View
            key={item.label}
            style={[styles.statCard, { backgroundColor: colors.surface, borderColor: colors.border }]}
          >
            <Text style={[styles.statValue, { color: colors.text }]}>
              {item.value.toLocaleString()}
            </Text>
            <Text style={[styles.statLabel, { color: colors.textMuted }]}>
              {item.label}
            </Text>
          </View>
        ))}
      </View>

      {/* Action Buttons */}
      <View style={styles.actionRow}>
        <TouchableOpacity
          onPress={resetCurrent}
          style={[styles.resetBtn, { backgroundColor: colors.surface2, borderColor: colors.border }]}
        >
          <Text style={[styles.resetText, { color: colors.textSub }]}>{t.reset}</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => { setGoalInput(String(activeDhikr?.target ?? 33)); setShowGoalModal(true); }}
          style={styles.goalBtnWrapper}
        >
          <LinearGradient
            colors={[theme.primary, theme.secondary]}
            style={styles.goalBtn}
          >
            <Text style={styles.goalBtnText}>{t.setGoal}</Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>

      {/* Congrats Overlay */}
      {showCongrats && (
        <Animated.View
          style={[
            styles.congratsOverlay,
            { opacity: congratsAnim, transform: [{ scale: congratsAnim }] },
          ]}
          pointerEvents="none"
        >
          <View style={[styles.congratsCard, { backgroundColor: colors.surface, borderColor: theme.accent }]}>
            <Text style={styles.congratsEmoji}>🎉</Text>
            <Text style={[styles.congratsTitle, { color: theme.accent }]}>{t.congratulations}</Text>
            <Text style={[styles.congratsSub, { color: colors.textSub }]}>{t.goalReached}</Text>
          </View>
        </Animated.View>
      )}

      {/* Goal Modal */}
      <Modal visible={showGoalModal} transparent animationType="slide">
        <View style={styles.modalBg}>
          <View style={[styles.modalSheet, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>{t.setGoal}</Text>

            <View style={styles.presetRow}>
              {[33, 99, 100, 1000].map(p => (
                <TouchableOpacity
                  key={p}
                  onPress={() => setGoalInput(String(p))}
                  style={[
                    styles.presetBtn,
                    {
                      backgroundColor: goalInput === String(p) ? theme.primary + '22' : colors.surface2,
                      borderColor: goalInput === String(p) ? theme.primary : colors.border,
                    },
                  ]}
                >
                  <Text style={[
                    styles.presetText,
                    { color: goalInput === String(p) ? theme.primary : colors.text },
                  ]}>{p}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <TextInput
              value={goalInput}
              onChangeText={setGoalInput}
              keyboardType="numeric"
              style={[styles.goalInput, { backgroundColor: colors.surface2, borderColor: colors.border, color: colors.text }]}
              placeholderTextColor={colors.textMuted}
            />

            <View style={styles.modalBtns}>
              <TouchableOpacity
                onPress={() => setShowGoalModal(false)}
                style={[styles.modalCancelBtn, { backgroundColor: colors.surface2, borderColor: colors.border }]}
              >
                <Text style={[styles.modalCancelText, { color: colors.textSub }]}>{t.cancel}</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={async () => {
                  const val = parseInt(goalInput);
                  if (val > 0) await updateDhikr(activeDhikrId, { target: val });
                  setShowGoalModal(false);
                }}
                style={styles.modalSaveBtnWrapper}
              >
                <LinearGradient colors={[theme.primary, theme.secondary]} style={styles.modalSaveBtn}>
                  <Text style={styles.modalSaveText}>{t.save}</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', paddingTop: 12 },
  selectorRow: { maxHeight: 52, width: '100%' },
  selectorContent: { paddingHorizontal: 16, gap: 8, alignItems: 'center' },
  selectorChip: {
    paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20,
    borderWidth: 1, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.3, shadowRadius: 4, elevation: 3,
  },
  selectorText: { fontSize: 13, fontWeight: '600' },
  arabicText: { fontSize: 30, fontFamily: 'serif', marginTop: 16, marginBottom: 2, textAlign: 'center' },
  dhikrLatinName: { fontSize: 13, marginBottom: 8 },
  buttonWrapper: { alignItems: 'center', justifyContent: 'center', marginVertical: 16, position: 'relative' },
  glowRing: {
    position: 'absolute', width: 230, height: 230, borderRadius: 115,
    borderWidth: 2,
  },
  counterBtn: {
    width: 200, height: 200, borderRadius: 100,
    alignItems: 'center', justifyContent: 'center',
    shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.5, shadowRadius: 20, elevation: 12,
  },
  counterNumber: { color: '#fff', fontSize: 68, fontWeight: '800', lineHeight: 72 },
  tapLabel: { color: 'rgba(255,255,255,0.6)', fontSize: 12, marginTop: 2 },
  progressSection: { width: width - 48, marginBottom: 16 },
  progressLabels: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  progressLabel: { fontSize: 12 },
  progressTrack: { height: 8, borderRadius: 4, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 4 },
  statsRow: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  statCard: {
    flex: 1, alignItems: 'center', padding: 12, borderRadius: 14, borderWidth: 1,
  },
  statValue: { fontSize: 20, fontWeight: '700' },
  statLabel: { fontSize: 11, marginTop: 2 },
  actionRow: { flexDirection: 'row', gap: 12, width: width - 48 },
  resetBtn: {
    flex: 1, padding: 14, borderRadius: 14, borderWidth: 1,
    alignItems: 'center', justifyContent: 'center',
  },
  resetText: { fontWeight: '600', fontSize: 14 },
  goalBtnWrapper: { flex: 2, borderRadius: 14, overflow: 'hidden' },
  goalBtn: { padding: 14, alignItems: 'center', justifyContent: 'center' },
  goalBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  congratsOverlay: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
    alignItems: 'center', justifyContent: 'center',
  },
  congratsCard: {
    borderRadius: 24, padding: 32, alignItems: 'center',
    borderWidth: 2, shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.3, shadowRadius: 20, elevation: 10,
  },
  congratsEmoji: { fontSize: 56, marginBottom: 8 },
  congratsTitle: { fontSize: 22, fontWeight: '800' },
  congratsSub: { fontSize: 14, marginTop: 4 },
  modalBg: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'flex-end',
  },
  modalSheet: {
    borderTopLeftRadius: 24, borderTopRightRadius: 24,
    padding: 24, borderWidth: 1, borderBottomWidth: 0,
  },
  modalTitle: { fontSize: 18, fontWeight: '700', marginBottom: 16 },
  presetRow: { flexDirection: 'row', gap: 8, marginBottom: 12 },
  presetBtn: { flex: 1, padding: 12, borderRadius: 12, borderWidth: 1, alignItems: 'center' },
  presetText: { fontWeight: '600', fontSize: 16 },
  goalInput: {
    borderWidth: 1, borderRadius: 12, padding: 12,
    fontSize: 18, textAlign: 'center', marginBottom: 16,
  },
  modalBtns: { flexDirection: 'row', gap: 12 },
  modalCancelBtn: {
    flex: 1, padding: 14, borderRadius: 14, borderWidth: 1,
    alignItems: 'center',
  },
  modalCancelText: { fontWeight: '600' },
  modalSaveBtnWrapper: { flex: 2, borderRadius: 14, overflow: 'hidden' },
  modalSaveBtn: { padding: 14, alignItems: 'center' },
  modalSaveText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});
