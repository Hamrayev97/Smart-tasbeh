// src/screens/SettingsScreen.js
import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView, Switch, Modal,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '../hooks/useAppContext';
import { THEMES } from '../data/themes';
import { LANG_NAMES } from '../data/languages';

export default function SettingsScreen() {
  const {
    t, theme, colors, darkMode, themeId,
    soundOn, vibrationOn, autoReset, isPremium, lang,
    setDarkMode, setThemeId, setSoundOn, setVibrationOn,
    setAutoReset, setLang, setIsPremium,
  } = useApp();

  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [showLangModal, setShowLangModal] = useState(false);

  const ToggleRow = ({ label, icon, value, onChange }) => (
    <View style={[styles.toggleRow, { borderBottomColor: colors.border }]}>
      <View style={styles.toggleLeft}>
        <Text style={styles.toggleIcon}>{icon}</Text>
        <Text style={[styles.toggleLabel, { color: colors.text }]}>{label}</Text>
      </View>
      <Switch
        value={value}
        onValueChange={onChange}
        trackColor={{ false: colors.surface2, true: theme.primary + '88' }}
        thumbColor={value ? theme.primary : '#888'}
        ios_backgroundColor={colors.surface2}
      />
    </View>
  );

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.bg }]}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      {/* Appearance */}
      <Text style={[styles.groupLabel, { color: colors.textMuted }]}>APPEARANCE</Text>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <ToggleRow
          label={t.darkMode}
          icon="🌙"
          value={darkMode}
          onChange={setDarkMode}
        />

        {/* Theme picker */}
        <View style={[styles.themeRow, { borderBottomColor: colors.border }]}>
          <View style={styles.toggleLeft}>
            <Text style={styles.toggleIcon}>🎨</Text>
            <Text style={[styles.toggleLabel, { color: colors.text }]}>{t.colorTheme}</Text>
          </View>
          <View style={styles.themeSwatches}>
            {Object.values(THEMES).map(th => (
              <TouchableOpacity
                key={th.id}
                onPress={() => setThemeId(th.id)}
                style={[
                  styles.swatch,
                  { backgroundColor: th.primary },
                  themeId === th.id && { borderWidth: 3, borderColor: '#fff' },
                ]}
              />
            ))}
          </View>
        </View>

        {/* Language */}
        <TouchableOpacity
          onPress={() => setShowLangModal(true)}
          style={styles.toggleRow}
        >
          <View style={styles.toggleLeft}>
            <Text style={styles.toggleIcon}>🌍</Text>
            <Text style={[styles.toggleLabel, { color: colors.text }]}>{t.language}</Text>
          </View>
          <Text style={[styles.langValue, { color: theme.primary }]}>
            {LANG_NAMES[lang]} ›
          </Text>
        </TouchableOpacity>
      </View>

      {/* Behavior */}
      <Text style={[styles.groupLabel, { color: colors.textMuted }]}>BEHAVIOR</Text>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <ToggleRow label={t.sound} icon="🔊" value={soundOn} onChange={setSoundOn} />
        <ToggleRow label={t.vibration} icon="📳" value={vibrationOn} onChange={setVibrationOn} />
        <ToggleRow label={t.autoReset} icon="🔄" value={autoReset} onChange={setAutoReset} />
      </View>

      {/* Premium */}
      <Text style={[styles.groupLabel, { color: colors.textMuted }]}>SUBSCRIPTION</Text>
      <TouchableOpacity onPress={() => setShowPremiumModal(true)}>
        <LinearGradient
          colors={isPremium ? ['#059669', '#064E3B'] : [theme.accent, '#B7791F']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={styles.premiumBtn}
        >
          <Text style={styles.premiumBtnText}>
            {isPremium ? '✅ Premium Active' : `⭐ ${t.premiumUnlock}`}
          </Text>
          <Text style={styles.premiumBtnSub}>
            {isPremium ? 'All features unlocked' : 'Remove ads & unlock all'}
          </Text>
        </LinearGradient>
      </TouchableOpacity>

      {/* Version */}
      <Text style={[styles.version, { color: colors.textMuted }]}>
        Smart Tasbeh v1.0.0 • Made with ❤️
      </Text>

      {/* Language Modal */}
      <Modal visible={showLangModal} transparent animationType="slide">
        <View style={styles.modalBg}>
          <View style={[styles.modalSheet, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>{t.language}</Text>
            <ScrollView>
              <View style={styles.langGrid}>
                {Object.entries(LANG_NAMES).map(([code, name]) => (
                  <TouchableOpacity
                    key={code}
                    onPress={() => { setLang(code); setShowLangModal(false); }}
                    style={[
                      styles.langBtn,
                      {
                        backgroundColor: lang === code ? theme.primary + '22' : colors.surface2,
                        borderColor: lang === code ? theme.primary : colors.border,
                      },
                    ]}
                  >
                    <Text style={[
                      styles.langBtnText,
                      { color: lang === code ? theme.primary : colors.text },
                    ]}>{name}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
            <TouchableOpacity
              onPress={() => setShowLangModal(false)}
              style={[styles.closeBtn, { backgroundColor: colors.surface2, borderColor: colors.border }]}
            >
              <Text style={[styles.closeBtnText, { color: colors.textSub }]}>{t.close}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Premium Modal */}
      <Modal visible={showPremiumModal} transparent animationType="slide">
        <View style={styles.modalBg}>
          <View style={[styles.modalSheet, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={styles.premiumModalEmoji}>⭐</Text>
            <Text style={[styles.premiumModalTitle, { color: theme.accent }]}>{t.premium}</Text>
            <Text style={[styles.premiumModalSub, { color: colors.textMuted }]}>
              Unlock the full experience
            </Text>

            <View style={styles.planRow}>
              {[
                { name: t.free, price: '$0', features: ['Basic counting', '5 dhikrs', 'Ads shown'], active: !isPremium },
                { name: t.premium, price: '$2.99', features: [t.noAds, t.extraThemes, t.advancedStats], active: isPremium },
              ].map(p => (
                <View
                  key={p.name}
                  style={[
                    styles.planCard,
                    {
                      backgroundColor: p.active ? theme.accent + '11' : colors.surface2,
                      borderColor: p.active ? theme.accent : colors.border,
                    },
                  ]}
                >
                  <Text style={[styles.planName, { color: p.active ? theme.accent : colors.text }]}>
                    {p.name}
                  </Text>
                  <Text style={[styles.planPrice, { color: theme.primary }]}>{p.price}</Text>
                  {p.features.map(f => (
                    <Text key={f} style={[styles.planFeature, { color: colors.textMuted }]}>✓ {f}</Text>
                  ))}
                </View>
              ))}
            </View>

            {!isPremium && (
              <TouchableOpacity
                onPress={() => { setIsPremium(true); setShowPremiumModal(false); }}
                style={{ borderRadius: 16, overflow: 'hidden', marginBottom: 12 }}
              >
                <LinearGradient
                  colors={[theme.accent, '#B7791F']}
                  style={styles.buyBtn}
                >
                  <Text style={styles.buyBtnText}>🚀 {t.premiumUnlock} — $2.99</Text>
                </LinearGradient>
              </TouchableOpacity>
            )}

            <TouchableOpacity
              onPress={() => setShowPremiumModal(false)}
              style={[styles.closeBtn, { backgroundColor: colors.surface2, borderColor: colors.border }]}
            >
              <Text style={[styles.closeBtnText, { color: colors.textSub }]}>{t.close}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 16, paddingBottom: 40 },
  groupLabel: {
    fontSize: 11, fontWeight: '700', letterSpacing: 1,
    marginBottom: 8, marginTop: 16, marginLeft: 4,
  },
  card: { borderRadius: 16, borderWidth: 1, marginBottom: 4, overflow: 'hidden' },
  toggleRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1,
  },
  toggleLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  toggleIcon: { fontSize: 20 },
  toggleLabel: { fontSize: 15 },
  themeRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1,
  },
  themeSwatches: { flexDirection: 'row', gap: 8 },
  swatch: {
    width: 26, height: 26, borderRadius: 13,
  },
  langValue: { fontSize: 14, fontWeight: '600' },
  premiumBtn: {
    borderRadius: 16, padding: 18, alignItems: 'center',
    shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 10, elevation: 6,
  },
  premiumBtnText: { color: '#fff', fontSize: 18, fontWeight: '800' },
  premiumBtnSub: { color: 'rgba(255,255,255,0.7)', fontSize: 12, marginTop: 4 },
  version: { textAlign: 'center', fontSize: 12, marginTop: 24 },
  modalBg: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  modalSheet: {
    borderTopLeftRadius: 24, borderTopRightRadius: 24,
    padding: 24, borderWidth: 1, borderBottomWidth: 0, maxHeight: '80%',
  },
  modalTitle: { fontSize: 18, fontWeight: '700', marginBottom: 16 },
  langGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 16 },
  langBtn: {
    width: '47%', padding: 12, borderRadius: 12, borderWidth: 1, alignItems: 'center',
  },
  langBtnText: { fontSize: 14, fontWeight: '500' },
  closeBtn: {
    padding: 14, borderRadius: 14, borderWidth: 1, alignItems: 'center',
  },
  closeBtnText: { fontWeight: '600' },
  premiumModalEmoji: { fontSize: 48, textAlign: 'center', marginBottom: 8 },
  premiumModalTitle: { fontSize: 24, fontWeight: '800', textAlign: 'center' },
  premiumModalSub: { fontSize: 14, textAlign: 'center', marginBottom: 20 },
  planRow: { flexDirection: 'row', gap: 12, marginBottom: 20 },
  planCard: { flex: 1, borderRadius: 16, padding: 16, borderWidth: 2 },
  planName: { fontSize: 15, fontWeight: '700' },
  planPrice: { fontSize: 20, fontWeight: '800', marginVertical: 6 },
  planFeature: { fontSize: 12, marginTop: 2 },
  buyBtn: { padding: 16, alignItems: 'center' },
  buyBtnText: { color: '#000', fontSize: 16, fontWeight: '800' },
});
