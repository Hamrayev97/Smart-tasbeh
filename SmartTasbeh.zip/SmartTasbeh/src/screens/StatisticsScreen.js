// src/screens/StatisticsScreen.js
import React from 'react';
import {
  View, Text, ScrollView, StyleSheet, Dimensions, TouchableOpacity,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '../hooks/useAppContext';

const { width } = Dimensions.get('window');
const BAR_WIDTH = (width - 80) / 7;

export default function StatisticsScreen({ onUpgrade }) {
  const {
    t, theme, colors,
    dhikrs, isPremium,
    getTodayTotal, getWeeklyTotal, getMonthlyTotal, getLifetimeTotal,
    getMostRecited, getWeeklyData,
  } = useApp();

  const weekData = getWeeklyData();
  const maxVal = Math.max(...weekData.map(d => d.value), 1);

  const summaryCards = [
    { label: t.today, value: getTodayTotal(), icon: '🌟' },
    { label: t.weekly, value: getWeeklyTotal(), icon: '📅' },
    { label: t.monthly, value: getMonthlyTotal(), icon: '🗓️' },
    { label: t.lifetime, value: getLifetimeTotal(), icon: '✨' },
  ];

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.bg }]}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      {/* Summary Grid */}
      <View style={styles.grid}>
        {summaryCards.map(card => (
          <View
            key={card.label}
            style={[styles.summaryCard, { backgroundColor: colors.surface, borderColor: colors.border }]}
          >
            <Text style={styles.cardIcon}>{card.icon}</Text>
            <Text style={[styles.cardValue, { color: colors.text }]}>
              {card.value.toLocaleString()}
            </Text>
            <Text style={[styles.cardLabel, { color: colors.textMuted }]}>{card.label}</Text>
          </View>
        ))}
      </View>

      {/* Most Recited */}
      <View style={[styles.sectionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Text style={[styles.sectionLabel, { color: colors.textMuted }]}>{t.mostRecited}</Text>
        <Text style={[styles.mostRecitedValue, { color: theme.accent }]}>{getMostRecited()}</Text>
      </View>

      {/* Weekly Bar Chart */}
      <View style={[styles.sectionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Text style={[styles.sectionTitle, { color: colors.text }]}>{t.weeklyChart}</Text>
        <View style={styles.chartContainer}>
          {weekData.map((d, i) => {
            const barH = Math.max(6, (d.value / maxVal) * 100);
            const isToday = i === 6;
            return (
              <View key={i} style={styles.barColumn}>
                {d.value > 0 && (
                  <Text style={[styles.barLabel, { color: colors.textMuted }]}>
                    {d.value > 999 ? `${(d.value / 1000).toFixed(1)}k` : d.value}
                  </Text>
                )}
                {isToday ? (
                  <LinearGradient
                    colors={[theme.accent, theme.primary]}
                    style={[styles.bar, { height: barH }]}
                  />
                ) : (
                  <View
                    style={[styles.bar, { height: barH, backgroundColor: theme.primary + '55' }]}
                  />
                )}
                <Text style={[styles.dayLabel, { color: isToday ? theme.primary : colors.textMuted }]}>
                  {d.label}
                </Text>
              </View>
            );
          })}
        </View>
      </View>

      {/* Per Dhikr Breakdown */}
      <View style={[styles.sectionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Text style={[styles.sectionTitle, { color: colors.text }]}>{t.dhikrList}</Text>
        {dhikrs.map((d, i) => {
          const pct = getLifetimeTotal() > 0
            ? Math.round((d.totalCount / getLifetimeTotal()) * 100)
            : 0;
          return (
            <View
              key={d.id}
              style={[
                styles.dhikrRow,
                { borderBottomColor: colors.border, borderBottomWidth: i < dhikrs.length - 1 ? 1 : 0 },
              ]}
            >
              <View style={[styles.dhikrDot, { backgroundColor: d.color }]} />
              <View style={{ flex: 1 }}>
                <Text style={[styles.dhikrName, { color: colors.text }]}>{d.name}</Text>
                <View style={[styles.dhikrBar, { backgroundColor: colors.surface2 }]}>
                  <View style={[styles.dhikrBarFill, { width: `${pct}%`, backgroundColor: d.color }]} />
                </View>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <Text style={[styles.dhikrCount, { color: theme.primary }]}>
                  {d.totalCount.toLocaleString()}
                </Text>
                <Text style={[styles.dhikrPct, { color: colors.textMuted }]}>{pct}%</Text>
              </View>
            </View>
          );
        })}
      </View>

      {/* Banner Ad (free) */}
      {!isPremium && (
        <TouchableOpacity
          onPress={onUpgrade}
          style={[styles.adBanner, { backgroundColor: colors.surface2, borderColor: colors.border }]}
        >
          <Text style={[styles.adText, { color: colors.textMuted }]}>📢 Advertisement</Text>
          <Text style={[styles.adSub, { color: colors.textMuted }]}>
            AdMob Banner — 320×50
          </Text>
          <View style={[styles.removeAdBtn, { backgroundColor: theme.accent }]}>
            <Text style={styles.removeAdText}>✨ Remove Ads</Text>
          </View>
        </TouchableOpacity>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 16, paddingBottom: 32 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 14 },
  summaryCard: {
    width: (width - 44) / 2, borderRadius: 16, padding: 16,
    alignItems: 'center', borderWidth: 1,
  },
  cardIcon: { fontSize: 24, marginBottom: 4 },
  cardValue: { fontSize: 26, fontWeight: '800' },
  cardLabel: { fontSize: 12, marginTop: 2 },
  sectionCard: {
    borderRadius: 16, padding: 16, borderWidth: 1, marginBottom: 14,
  },
  sectionLabel: { fontSize: 12, marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.8 },
  mostRecitedValue: { fontSize: 20, fontWeight: '700' },
  sectionTitle: { fontSize: 15, fontWeight: '700', marginBottom: 16 },
  chartContainer: { flexDirection: 'row', alignItems: 'flex-end', height: 130, gap: 4 },
  barColumn: { flex: 1, alignItems: 'center', gap: 4 },
  barLabel: { fontSize: 9 },
  bar: { width: '100%', borderRadius: 4 },
  dayLabel: { fontSize: 10, fontWeight: '600' },
  dhikrRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10 },
  dhikrDot: { width: 10, height: 10, borderRadius: 5 },
  dhikrName: { fontSize: 13, fontWeight: '500', marginBottom: 4 },
  dhikrBar: { height: 4, borderRadius: 2, overflow: 'hidden' },
  dhikrBarFill: { height: '100%', borderRadius: 2 },
  dhikrCount: { fontSize: 16, fontWeight: '700' },
  dhikrPct: { fontSize: 11 },
  adBanner: {
    borderRadius: 12, padding: 12, borderWidth: 1, borderStyle: 'dashed',
    alignItems: 'center', gap: 4,
  },
  adText: { fontSize: 11 },
  adSub: { fontSize: 12 },
  removeAdBtn: { marginTop: 6, paddingHorizontal: 16, paddingVertical: 6, borderRadius: 8 },
  removeAdText: { fontSize: 12, fontWeight: '600', color: '#000' },
});
