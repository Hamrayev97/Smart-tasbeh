// src/screens/DhikrListScreen.js
import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView,
  Modal, TextInput, Alert, Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '../hooks/useAppContext';
import { DHIKR_COLORS } from '../data/themes';

const { width } = Dimensions.get('window');

const EMPTY_FORM = { name: '', arabicName: '', target: 33, color: '#10B981' };

export default function DhikrListScreen() {
  const {
    t, theme, colors,
    dhikrs, activeDhikrId, setActiveDhikrId,
    addDhikr, updateDhikr, deleteDhikr,
  } = useApp();

  const [showModal, setShowModal] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteId, setDeleteId] = useState(null);

  const openAdd = () => {
    setForm(EMPTY_FORM);
    setEditId(null);
    setShowModal(true);
  };

  const openEdit = (d) => {
    setForm({ name: d.name, arabicName: d.arabicName || '', target: d.target, color: d.color });
    setEditId(d.id);
    setShowModal(true);
  };

  const handleSave = async () => {
    if (!form.name.trim()) return;
    if (editId) {
      await updateDhikr(editId, form);
    } else {
      await addDhikr(form);
    }
    setShowModal(false);
  };

  const handleDelete = async () => {
    await deleteDhikr(deleteId);
    setShowDeleteModal(false);
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.bg }]}>
      <ScrollView contentContainerStyle={styles.list} showsVerticalScrollIndicator={false}>
        {/* Add Button */}
        <TouchableOpacity
          onPress={openAdd}
          style={[styles.addBtn, { borderColor: theme.primary + '66' }]}
        >
          <Text style={[styles.addBtnText, { color: theme.primary }]}>+ {t.addDhikr}</Text>
        </TouchableOpacity>

        {/* Dhikr Cards */}
        {dhikrs.map(d => (
          <View
            key={d.id}
            style={[
              styles.card,
              {
                backgroundColor: colors.surface,
                borderColor: d.id === activeDhikrId ? d.color + '88' : colors.border,
                shadowColor: d.id === activeDhikrId ? d.color : 'transparent',
              },
            ]}
          >
            {/* Color dot / activate button */}
            <TouchableOpacity
              onPress={() => setActiveDhikrId(d.id)}
              style={[styles.activateBtn, { backgroundColor: d.color }]}
            >
              <Text style={styles.activateBtnText}>
                {d.id === activeDhikrId ? '✓' : d.name.charAt(0)}
              </Text>
            </TouchableOpacity>

            {/* Info */}
            <View style={styles.cardInfo}>
              <Text style={[styles.cardName, { color: colors.text }]}>{d.name}</Text>
              {d.arabicName ? (
                <Text style={[styles.cardArabic, { color: theme.accent }]}>{d.arabicName}</Text>
              ) : null}
              <Text style={[styles.cardMeta, { color: colors.textMuted }]}>
                {t.target}: {d.target} · {t.totalCount}: {d.totalCount.toLocaleString()}
              </Text>
              {/* Mini progress */}
              <View style={[styles.miniTrack, { backgroundColor: colors.surface2 }]}>
                <View
                  style={[
                    styles.miniFill,
                    {
                      width: `${Math.min(100, (d.currentCount / d.target) * 100)}%`,
                      backgroundColor: d.color,
                    },
                  ]}
                />
              </View>
            </View>

            {/* Actions */}
            <View style={styles.cardActions}>
              <TouchableOpacity
                onPress={() => openEdit(d)}
                style={[styles.iconBtn, { backgroundColor: colors.surface2, borderColor: colors.border }]}
              >
                <Text>✏️</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => { setDeleteId(d.id); setShowDeleteModal(true); }}
                style={[styles.iconBtn, { backgroundColor: '#FF000011', borderColor: '#FF000033' }]}
              >
                <Text>🗑️</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>

      {/* Add/Edit Modal */}
      <Modal visible={showModal} transparent animationType="slide">
        <View style={styles.modalBg}>
          <View style={[styles.modalSheet, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>
              {editId ? t.editDhikr : t.addDhikr}
            </Text>

            {/* Name */}
            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>{t.dhikrName}</Text>
            <TextInput
              value={form.name}
              onChangeText={v => setForm(f => ({ ...f, name: v }))}
              placeholder="Subhanallah"
              placeholderTextColor={colors.textMuted}
              style={[styles.input, { backgroundColor: colors.surface2, borderColor: colors.border, color: colors.text }]}
            />

            {/* Arabic */}
            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>Arabic Name</Text>
            <TextInput
              value={form.arabicName}
              onChangeText={v => setForm(f => ({ ...f, arabicName: v }))}
              placeholder="سُبْحَانَ اللّهِ"
              placeholderTextColor={colors.textMuted}
              textAlign="right"
              style={[styles.input, { backgroundColor: colors.surface2, borderColor: colors.border, color: colors.text }]}
            />

            {/* Target */}
            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>{t.target}</Text>
            <View style={styles.presetRow}>
              {[33, 99, 100].map(p => (
                <TouchableOpacity
                  key={p}
                  onPress={() => setForm(f => ({ ...f, target: p }))}
                  style={[
                    styles.presetBtn,
                    {
                      backgroundColor: form.target === p ? theme.primary + '22' : colors.surface2,
                      borderColor: form.target === p ? theme.primary : colors.border,
                    },
                  ]}
                >
                  <Text style={[styles.presetText, { color: form.target === p ? theme.primary : colors.text }]}>
                    {p}
                  </Text>
                </TouchableOpacity>
              ))}
              <TextInput
                value={String(form.target)}
                onChangeText={v => setForm(f => ({ ...f, target: parseInt(v) || 33 }))}
                keyboardType="numeric"
                style={[
                  styles.presetBtn, styles.customInput,
                  { backgroundColor: colors.surface2, borderColor: colors.border, color: colors.text },
                ]}
                placeholderTextColor={colors.textMuted}
              />
            </View>

            {/* Color */}
            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>{t.colorTheme}</Text>
            <View style={styles.colorRow}>
              {DHIKR_COLORS.map(c => (
                <TouchableOpacity
                  key={c}
                  onPress={() => setForm(f => ({ ...f, color: c }))}
                  style={[
                    styles.colorDot,
                    { backgroundColor: c },
                    form.color === c && styles.colorDotActive,
                  ]}
                />
              ))}
            </View>

            {/* Buttons */}
            <View style={styles.modalBtns}>
              <TouchableOpacity
                onPress={() => setShowModal(false)}
                style={[styles.cancelBtn, { backgroundColor: colors.surface2, borderColor: colors.border }]}
              >
                <Text style={[styles.cancelText, { color: colors.textSub }]}>{t.cancel}</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={handleSave} style={styles.saveBtnWrapper}>
                <LinearGradient colors={[theme.primary, theme.secondary]} style={styles.saveBtn}>
                  <Text style={styles.saveBtnText}>{t.save}</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Delete Confirm Modal */}
      <Modal visible={showDeleteModal} transparent animationType="fade">
        <View style={styles.modalBg}>
          <View style={[styles.confirmSheet, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={styles.confirmEmoji}>🗑️</Text>
            <Text style={[styles.confirmText, { color: colors.text }]}>{t.deleteConfirm}</Text>
            <View style={styles.modalBtns}>
              <TouchableOpacity
                onPress={() => setShowDeleteModal(false)}
                style={[styles.cancelBtn, { flex: 1, backgroundColor: colors.surface2, borderColor: colors.border }]}
              >
                <Text style={[styles.cancelText, { color: colors.textSub }]}>{t.cancel}</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleDelete}
                style={[styles.deleteBtn, { flex: 1 }]}
              >
                <Text style={styles.deleteBtnText}>{t.deleteDhikr}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  list: { padding: 16, gap: 10, paddingBottom: 32 },
  addBtn: {
    padding: 14, borderRadius: 14, borderWidth: 2,
    borderStyle: 'dashed', alignItems: 'center',
  },
  addBtnText: { fontSize: 15, fontWeight: '600' },
  card: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    padding: 14, borderRadius: 16, borderWidth: 1,
    shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.15, shadowRadius: 6, elevation: 3,
  },
  activateBtn: {
    width: 48, height: 48, borderRadius: 24,
    alignItems: 'center', justifyContent: 'center',
    shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.3, shadowRadius: 6, elevation: 4,
  },
  activateBtnText: { color: '#fff', fontSize: 18, fontWeight: '700' },
  cardInfo: { flex: 1 },
  cardName: { fontSize: 14, fontWeight: '600' },
  cardArabic: { fontSize: 16, textAlign: 'right' },
  cardMeta: { fontSize: 11, marginTop: 2 },
  miniTrack: { height: 3, borderRadius: 2, marginTop: 5, overflow: 'hidden' },
  miniFill: { height: '100%', borderRadius: 2 },
  cardActions: { gap: 6 },
  iconBtn: {
    width: 34, height: 34, borderRadius: 8, borderWidth: 1,
    alignItems: 'center', justifyContent: 'center',
  },
  modalBg: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  modalSheet: {
    borderTopLeftRadius: 24, borderTopRightRadius: 24,
    padding: 24, borderWidth: 1, borderBottomWidth: 0,
  },
  modalTitle: { fontSize: 18, fontWeight: '700', marginBottom: 16 },
  fieldLabel: { fontSize: 12, marginBottom: 6, marginTop: 10 },
  input: {
    borderWidth: 1, borderRadius: 12, padding: 12, fontSize: 15,
  },
  presetRow: { flexDirection: 'row', gap: 8 },
  presetBtn: {
    flex: 1, padding: 10, borderRadius: 10, borderWidth: 1,
    alignItems: 'center', justifyContent: 'center',
  },
  presetText: { fontWeight: '600', fontSize: 14 },
  customInput: { textAlign: 'center', fontSize: 14 },
  colorRow: { flexDirection: 'row', gap: 10, marginTop: 4, flexWrap: 'wrap' },
  colorDot: { width: 32, height: 32, borderRadius: 16 },
  colorDotActive: { borderWidth: 3, borderColor: '#fff', transform: [{ scale: 1.15 }] },
  modalBtns: { flexDirection: 'row', gap: 12, marginTop: 20 },
  cancelBtn: {
    flex: 1, padding: 14, borderRadius: 14, borderWidth: 1,
    alignItems: 'center',
  },
  cancelText: { fontWeight: '600' },
  saveBtnWrapper: { flex: 2, borderRadius: 14, overflow: 'hidden' },
  saveBtn: { padding: 14, alignItems: 'center' },
  saveBtnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  confirmSheet: {
    margin: 32, borderRadius: 24, padding: 24,
    borderWidth: 1, alignItems: 'center',
  },
  confirmEmoji: { fontSize: 40, marginBottom: 12 },
  confirmText: { fontSize: 16, fontWeight: '600', marginBottom: 20, textAlign: 'center' },
  deleteBtn: {
    padding: 14, borderRadius: 14, backgroundColor: '#FF6B6B',
    alignItems: 'center',
  },
  deleteBtnText: { color: '#fff', fontWeight: '700' },
});
